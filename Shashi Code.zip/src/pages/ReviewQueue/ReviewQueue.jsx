import React, { useState } from 'react';
import { Eye, FileText, CheckCircle, XCircle } from 'lucide-react';
import './ReviewQueue.css';

const MOCK_APPLICATIONS = [
  { id: 'APP-001', name: 'Raman Associates', dsaCode: 'TEMP-ABCD1234', date: '14-04-2026', status: 'Pending', step: 'Review' },
  { id: 'APP-002', name: 'Shivam Sharma', dsaCode: 'TEMP-XYZA5678', date: '15-04-2026', status: 'Query Raised', step: 'Compliance' },
  { id: 'APP-003', name: 'Alok Traders', dsaCode: 'TEMP-LMNO9012', date: '16-04-2026', status: 'Approved', step: 'Completed' },
];

const ReviewQueue = () => {
  const [selectedApp, setSelectedApp] = useState(null);

  return (
    <div className="review-queue-page">
      <h1 className="page-title">Review Queue</h1>
      
      {!selectedApp ? (
        <div className="glass-panel p-0 animate-fade-in">
          <table className="review-table">
            <thead>
              <tr>
                <th>App ID</th>
                <th>DSA Name</th>
                <th>Temp Code</th>
                <th>Date Submitted</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {MOCK_APPLICATIONS.map((app) => (
                <tr key={app.id}>
                  <td><strong>{app.id}</strong></td>
                  <td>{app.name}</td>
                  <td>{app.dsaCode}</td>
                  <td>{app.date}</td>
                  <td>
                    <span className={`badge badge-${app.status === 'Approved' ? 'success' : app.status === 'Pending' ? 'warning' : 'danger'}`}>
                      {app.status}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-outline btn-sm" onClick={() => setSelectedApp(app)}>
                      <Eye size={16} /> Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="review-details animate-fade-in">
          <div className="flex justify-between items-center mb-4">
            <button className="btn btn-outline" onClick={() => setSelectedApp(null)}>Back to Queue</button>
            <div className="flex gap-2">
              <button className="btn btn-outline"><XCircle size={16} className="text-danger"/> Raise Query</button>
              <button className="btn btn-primary"><CheckCircle size={16} /> Approve Case</button>
            </div>
          </div>
          
          <div className="review-grid">
            <div className="glass-panel review-section">
              <h3>Applicant Details</h3>
              <div className="detail-row"><span>Name:</span> <strong>{selectedApp.name}</strong></div>
              <div className="detail-row"><span>Temp Code:</span> <strong>{selectedApp.dsaCode}</strong></div>
              <div className="detail-row"><span>Mobile:</span> <strong>9876543210</strong></div>
              <div className="detail-row"><span>Vendor Category:</span> <strong>Individual</strong></div>
            </div>
            
            <div className="glass-panel review-section">
              <h3>Documents Uploaded</h3>
              <ul className="doc-list">
                <li><FileText size={16} /> PAN Card <span className="badge badge-success ml-auto">Verified</span></li>
                <li><FileText size={16} /> GST Certificate <span className="badge badge-success ml-auto">Verified</span></li>
                <li><FileText size={16} /> Cancelled Cheque <span className="badge badge-warning ml-auto">Pending Review</span></li>
              </ul>
            </div>
            
            <div className="glass-panel review-section full-width">
              <h3>Payout Details & Checks</h3>
              <div className="detail-row"><span>Requested Payout:</span> <strong>1.50% (Standard)</strong></div>
              <div className="detail-row"><span>CIBIL Score:</span> <strong className="text-success">780</strong></div>
              <div className="detail-row"><span>BRE Rules:</span> <strong className="text-success">Passed</strong></div>
              <div className="detail-row"><span>Dedupe Check:</span> <strong className="text-success">Clear</strong></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewQueue;
