import React, { useState } from 'react';
import { Loader2, CheckCircle, FileText, Smartphone } from 'lucide-react';
import './Onboarding.css';

const STEPS = [
  'Vendor Category',
  'Banking Verification',
  'Identity & Address OCR',
  'Entity Details',
  'Personal & KYC',
  'Additional Documents',
  'Payout Selection',
  'E-Signing'
];

const VENDOR_CATEGORIES = [
  'DSA', 'Connector', 'Technical', 'Legal', 'RCU', 'PD', 'Legal Recovery', 
  'Collection Vendor', 'Branch Admin Vendors', 'HO Vendors', 'Other'
];

// Removed ID Proof and Address Proof from matrices since they are collected in Step 1 (OCR)
const DOCUMENT_MATRIX = {
  'DSA': ['Vendor Empanelment Form', 'PAN/Form 60', 'Vendor Income', 'Cancelled Cheque', 'Agreement', 'Stamp Paper', 'Profile (CV, Photo)', 'GST & MSME Certificate', 'Declaration from Employee', 'DSA empanelment form', 'Enrollment letter from other FI'],
  'Connector': ['Vendor Empanelment Form', 'PAN/Form 60', 'Vendor Income', 'Cancelled Cheque', 'Agreement', 'Stamp Paper', 'Profile (CV, Photo)', 'GST & MSME Certificate', 'Declaration from vendor on relationship', 'Declaration from Employee', 'DSA empanelment form', 'Enrollment letter from other FI'],
  'Legal': ['Vendor Empanelment Form', 'PAN/Form 60', 'Vendor Income', 'Cancelled Cheque', 'Agreement', 'Stamp Paper', 'Profile (CV, Photo)', 'GST & MSME Certificate', 'Professional Docs', 'Educational Certificates', 'References', 'Legal Degree & Bar Council License'],
  'Technical': ['Vendor Empanelment Form', 'PAN/Form 60', 'Vendor Income', 'Cancelled Cheque', 'Agreement', 'Stamp Paper', 'Profile (CV, Photo)', 'GST & MSME Certificate', 'Professional Docs', 'Educational Certificates', 'References'],
  'RCU': ['Vendor Empanelment Form', 'PAN/Form 60', 'Vendor Income', 'Cancelled Cheque', 'Agreement', 'Stamp Paper', 'GST & MSME Certificate'],
  'Other': ['Vendor Empanelment Form', 'PAN/Form 60', 'Cancelled Cheque']
};

const Onboarding = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [activeExtraction, setActiveExtraction] = useState(null);
  const [extractionStatus, setExtractionStatus] = useState({
    companyBank: false,
    partnerBanks: [],
    companyOcr: false,
    partnerOcr: []
  });
  
  const [formData, setFormData] = useState({
    // Step 0: Banking
    bankName: '',
    accountNumber: '',
    ifscCode: '',
    
    // Step 1: OCR
    idProofFile: null,
    addressProofFile: null,
    
    // Step 2 & 3: Forms (Pre-populated + Manual)
    vendorCategory: 'DSA',
    companyName: '',
    entityType: 'Individual',
    numberOfPartners: 0,
    partnerDetails: [],
    partnerBankDetails: [],
    partnerOcrDetails: [],
    dateOfInc: '',
    classOfActivity: '',
    cin: '',
    annualTurnover: '',
    yearsOfExperience: '',
    
    registeredAddress: '',
    state: '',
    city: '',
    pincode: '',
    serviceLocations: '',
    serviceState: '',
    serviceCity: '',
    serviceBranch: '',
    email: '',
    phone: '',
    altContactNumber: '',
    phoneOtp: '',
    emailOtp: '',
    showPhoneOtp: false,
    showEmailOtp: false,
    phoneVerified: false,
    emailVerified: false,
    phoneOtpError: '',
    emailOtpError: '',
    partnerCountError: '',
    
    fullName: '',
    fatherName: '',
    dob: '',
    designation: '',
    personalMobile: '',
    
    companyPan: '',
    individualPan: '',
    aadharNumber: '',
    gstNumber: '',
    msmeRegistered: 'No',
    idType: 'Voter ID',
    keyClients: '',
    
    refName: '',
    refContact: '',
    refRelationship: '',
    refEmail: '',
    
    assessedByName: '',
    assessedByDepartment: '',
    assessedByDesignation: '',
    meetingDate: '',
    
    spocName: '',
    spocDesignation: '',
    spocEmail: '',
    spocPhone: '',
    
    ref1Inst: '',
    ref1Location: '',
    ref2Inst: '',
    ref2Location: ''
  });

  const nextStep = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const initPartnerDetail = () => ({
    fullName: '',
    dob: '',
    pan: '',
    designation: '',
    role: '',
    sharePercentage: ''
  });

  const initPartnerBank = () => ({
    bankName: '',
    accountNumber: '',
    ifscCode: ''
  });

  const initPartnerOcr = () => ({
    idProofFile: null,
    addressProofFile: null,
    fullName: '',
    dob: '',
    pan: '',
    aadharNumber: ''
  });

  const adjustPartnerArrays = (count, prev) => {
    const partnerDetails = Array.from({ length: count }, (_, idx) => prev.partnerDetails[idx] || initPartnerDetail());
    const partnerBankDetails = Array.from({ length: count }, (_, idx) => prev.partnerBankDetails[idx] || initPartnerBank());
    const partnerOcrDetails = Array.from({ length: count }, (_, idx) => prev.partnerOcrDetails[idx] || initPartnerOcr());
    return { partnerDetails, partnerBankDetails, partnerOcrDetails };
  };

  const adjustStatusArray = (count, statusArray = []) =>
    Array.from({ length: count }, (_, idx) => statusArray[idx] || false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSendPhoneOtp = () => {
    setFormData(prev => ({
      ...prev,
      showPhoneOtp: true,
      phoneOtpError: '',
      phoneVerified: false
    }));
  };

  const handleVerifyPhoneOtp = () => {
    setFormData(prev => {
      const isValid = prev.phoneOtp === '12345';
      return {
        ...prev,
        phoneVerified: isValid,
        phoneOtpError: isValid ? '' : 'Invalid OTP. Please use 12345.',
        showPhoneOtp: !isValid
      };
    });
  };

  const handleSendEmailOtp = () => {
    setFormData(prev => ({
      ...prev,
      showEmailOtp: true,
      emailOtpError: '',
      emailVerified: false
    }));
  };

  const handleVerifyEmailOtp = () => {
    setFormData(prev => {
      const isValid = prev.emailOtp === '12345';
      return {
        ...prev,
        emailVerified: isValid,
        emailOtpError: isValid ? '' : 'Invalid OTP. Please use 12345.',
        showEmailOtp: !isValid
      };
    });
  };

  const handleEntityTypeChange = (e) => {
    const value = e.target.value;
    setExtractionStatus(prev => ({
      ...prev,
      partnerBanks: value === 'Individual' ? [] : adjustStatusArray(Math.max(1, formData.numberOfPartners || 1), prev.partnerBanks),
      partnerOcr: value === 'Individual' ? [] : adjustStatusArray(Math.max(1, formData.numberOfPartners || 1), prev.partnerOcr)
    }));
    setFormData(prev => {
      const update = { ...prev, entityType: value };
      if (value === 'Individual') {
        update.numberOfPartners = 0;
        update.partnerDetails = [];
        update.partnerBankDetails = [];
        update.partnerOcrDetails = [];
      } else {
        const count = prev.numberOfPartners || 1;
        const { partnerDetails, partnerBankDetails, partnerOcrDetails } = adjustPartnerArrays(count, prev);
        update.numberOfPartners = count;
        update.partnerDetails = partnerDetails;
        update.partnerBankDetails = partnerBankDetails;
        update.partnerOcrDetails = partnerOcrDetails;
      }
      return update;
    });
  };

  const handleNumberOfPartnersChange = (e) => {
    const value = Number(e.target.value);
    const count = Number.isNaN(value) ? 0 : Math.min(10, Math.max(0, value));
    const error = count === 0 ? 'Number of partners/directors cannot be 0.' : '';

    setExtractionStatus(prev => ({
      ...prev,
      partnerBanks: adjustStatusArray(count, prev.partnerBanks),
      partnerOcr: adjustStatusArray(count, prev.partnerOcr)
    }));

    setFormData(prev => {
      const updated = { ...prev, numberOfPartners: count, partnerCountError: error };
      if (count > 0) {
        const { partnerDetails, partnerBankDetails, partnerOcrDetails } = adjustPartnerArrays(count, prev);
        updated.partnerDetails = partnerDetails;
        updated.partnerBankDetails = partnerBankDetails;
        updated.partnerOcrDetails = partnerOcrDetails;
      } else {
        updated.partnerDetails = [];
        updated.partnerBankDetails = [];
        updated.partnerOcrDetails = [];
      }
      return updated;
    });
  };

  const handlePartnerDetailChange = (index, name, value) => {
    setFormData(prev => {
      const partnerDetails = [...prev.partnerDetails];
      partnerDetails[index] = { ...partnerDetails[index], [name]: value };
      return { ...prev, partnerDetails };
    });
  };

  const handlePartnerBankChange = (index, name, value) => {
    setFormData(prev => {
      const partnerBankDetails = [...prev.partnerBankDetails];
      partnerBankDetails[index] = { ...partnerBankDetails[index], [name]: value };
      return { ...prev, partnerBankDetails };
    });
  };

  const handlePartnerOcrChange = (index, name, value) => {
    setFormData(prev => {
      const partnerOcrDetails = [...prev.partnerOcrDetails];
      partnerOcrDetails[index] = { ...partnerOcrDetails[index], [name]: value };
      return { ...prev, partnerOcrDetails };
    });
  };

  const handleCompanyOcrFileChange = (name, file) => {
    setFormData(prev => ({ ...prev, [name]: file }));
  };

  const simulateCompanyBankingExtraction = () => {
    setActiveExtraction('companyBank');
    setTimeout(() => {
      setFormData(prev => {
        return {
          ...prev,
          bankName: prev.bankName || 'ICICI Bank',
          accountNumber: prev.accountNumber || '100001507308',
          ifscCode: prev.ifscCode || 'ICIC0001001',
          companyName: prev.companyName || 'India Shelter Example Pvt Ltd'
        };
      });
      setExtractionStatus(prev => ({ ...prev, companyBank: true }));
      setActiveExtraction(null);
    }, 1500);
  };

  const simulatePartnerBankingExtraction = (index) => {
    setActiveExtraction(`partnerBank-${index}`);
    setTimeout(() => {
      setFormData(prev => {
        const partnerBankDetails = [...prev.partnerBankDetails];
        const existingBank = partnerBankDetails[index] || initPartnerBank();
        partnerBankDetails[index] = {
          ...existingBank,
          bankName: existingBank.bankName || `Partner Bank ${index + 1}`,
          accountNumber: existingBank.accountNumber || `4000${index + 1}000${index + 1}08`,
          ifscCode: existingBank.ifscCode || `ICIC0000${index + 1}`
        };

        return {
          ...prev,
          partnerBankDetails
        };
      });
      setExtractionStatus(prev => {
        const partnerBanks = [...prev.partnerBanks];
        partnerBanks[index] = true;
        return { ...prev, partnerBanks };
      });
      setActiveExtraction(null);
    }, 1500);
  };

  const simulateCompanyOCRExtraction = () => {
    setActiveExtraction('companyOcr');
    setTimeout(() => {
      setFormData(prev => ({
        ...prev,
        registeredAddress: prev.registeredAddress || 'House No 52, Bhawanipur, Shiv Mandir',
        state: prev.state || 'Uttar Pradesh',
        city: prev.city || 'Varanasi',
        pincode: prev.pincode || '221301',
        fullName: prev.fullName || 'Ashish Phoolchand Pandey',
        dob: prev.dob || '1984-03-31',
        individualPan: prev.individualPan || 'AMJPP1483B'
      }));
      setExtractionStatus(prev => ({ ...prev, companyOcr: true }));
      setActiveExtraction(null);
    }, 2000);
  };

  const simulatePartnerOCRExtraction = (index) => {
    setActiveExtraction(`partnerOcr-${index}`);
    setTimeout(() => {
      setFormData(prev => {
        const partnerOcrDetails = [...prev.partnerOcrDetails];
        const partnerDetails = [...prev.partnerDetails];
        const existingPartnerOcr = partnerOcrDetails[index] || initPartnerOcr();
        const existingPartnerDetails = partnerDetails[index] || initPartnerDetail();
        const extractedName = existingPartnerOcr.fullName || `Partner ${index + 1} Name`;
        const extractedDob = existingPartnerOcr.dob || '1990-01-01';
        const extractedPan = existingPartnerOcr.pan || `PNRPK000${index + 1}A`;
        const extractedAadhar = existingPartnerOcr.aadharNumber || `1234 5678 90${index + 1}`;

        partnerOcrDetails[index] = {
          ...existingPartnerOcr,
          fullName: extractedName,
          dob: extractedDob,
          pan: extractedPan,
          aadharNumber: extractedAadhar
        };

        partnerDetails[index] = {
          ...existingPartnerDetails,
          fullName: existingPartnerDetails.fullName || extractedName,
          dob: existingPartnerDetails.dob || extractedDob,
          pan: existingPartnerDetails.pan || extractedPan
        };

        return {
          ...prev,
          partnerOcrDetails,
          partnerDetails
        };
      });
      setExtractionStatus(prev => {
        const partnerOcr = [...prev.partnerOcr];
        partnerOcr[index] = true;
        return { ...prev, partnerOcr };
      });
      setActiveExtraction(null);
    }, 2000);
  };

  const isExtracting = (target) => activeExtraction === target;
  const verifiedPartnerBanks = extractionStatus.partnerBanks.filter(Boolean).length;
  const verifiedPartnerOcr = extractionStatus.partnerOcr.filter(Boolean).length;

  const requiredDocs = DOCUMENT_MATRIX[formData.vendorCategory] || DOCUMENT_MATRIX['Other'];

  return (
    <div className="onboarding-page">
      <div className="onboarding-header glass-panel">
        <h1 className="page-title">Register New Vendor / DSA</h1>
        <p className="text-muted text-sm mt-1">Smart Registration Flow</p>
        
        <div className="stepper mt-4">
          {STEPS.map((step, index) => (
            <div key={index} className={`step ${index <= currentStep ? 'active' : ''} ${index === currentStep ? 'current' : ''}`}>
              <div className="step-circle">{index + 1}</div>
              <span className="step-label">{step}</span>
              {index < STEPS.length - 1 && <div className="step-line"></div>}
            </div>
          ))}
        </div>
      </div>

      <div className="onboarding-content glass-panel animate-fade-in">
        
        {/* STEP 0: Vendor Category */}
        {currentStep === 0 && (
          <div className="step-content animate-fade-in">
            <div className="flex justify-between items-center border-bottom mb-4 pb-2">
              <h2>Vendor Category</h2>
              <span className="badge badge-success">Quick Setup</span>
            </div>

  
            <h3 className="section-subheading">Business Structure</h3>
            <div className="form-grid">
              <div className="input-group full-width">
                <label>Entity Type</label>
                <select name="entityType" value={formData.entityType} onChange={handleEntityTypeChange}>
                  <option>Individual</option>
                  <option>Proprietorship</option>
                  <option>Partnership</option>
                  <option>Firm</option>
                </select>
              </div>
              {formData.entityType !== 'Individual'&& formData.entityType !== 'Proprietorship' && (
                <div className="input-group full-width">
                  <label>Number of Partners / Directors</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={formData.numberOfPartners}
                    onChange={handleNumberOfPartnersChange}
                    placeholder="Enter number"
                  />
                  {formData.partnerCountError && <p className="text-error text-sm">{formData.partnerCountError}</p>}
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 1: Banking Verification */}
        {currentStep === 1 && (
          <div className="step-content animate-fade-in">
            <h2>Banking Verification</h2>
            <p className="mb-6 text-sm text-muted">We initiate banking verification for the company/firm and all partners listed.</p>
            
            <div className="banking-options">
              <div className="banking-card glass-panel">
                <h3>Company / Firm Bank</h3>
                <p>Verify company bank details and auto-fill from the selected account.</p>
                <button className="btn btn-primary mt-4" onClick={simulateCompanyBankingExtraction} disabled={activeExtraction !== null}>
                  {isExtracting('companyBank') ? <><Loader2 className="spin" size={16}/> Connecting...</> : 'Verify Company Bank'}
                </button>
              </div>
            </div>

            <div className="section-divider"></div>
            <h3 className="section-subheading mt-6">Company / Firm Bank Details</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Bank Name</label>
                <input type="text" name="bankName" value={formData.bankName} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Account Number</label>
                <input type="text" name="accountNumber" value={formData.accountNumber} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>IFSC Code</label>
                <input type="text" name="ifscCode" value={formData.ifscCode} onChange={handleInputChange} />
              </div>
            </div>

            {formData.entityType !== 'Individual' && formData.partnerBankDetails.length > 0 && (
              <>
                <div className="section-divider"></div>
                <h3 className="section-subheading mt-6">Partner / Director Bank Details</h3>
                {formData.partnerBankDetails.map((bank, idx) => (
                  <div className="partner-card glass-panel mt-4" key={idx}>
                    <div className="flex justify-between items-center mb-3">
                      <h4>Partner {idx + 1} Bank</h4>
                      <span className="badge badge-secondary">{formData.entityType}</span>
                    </div>
                    <button className="btn btn-outline mb-4" onClick={() => simulatePartnerBankingExtraction(idx)} disabled={activeExtraction !== null}>
                      {isExtracting(`partnerBank-${idx}`) ? <><Loader2 className="spin" size={16}/> Verifying...</> : `Verify Partner ${idx + 1} Bank`}
                    </button>
                    <div className="form-grid">
                      <div className="input-group">
                        <label>Bank Name</label>
                        <input type="text" value={bank.bankName} onChange={(e) => handlePartnerBankChange(idx, 'bankName', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>Account Number</label>
                        <input type="text" value={bank.accountNumber} onChange={(e) => handlePartnerBankChange(idx, 'accountNumber', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>IFSC Code</label>
                        <input type="text" value={bank.ifscCode} onChange={(e) => handlePartnerBankChange(idx, 'ifscCode', e.target.value)} />
                      </div>
                    </div>
                  </div>
                ))}
              </>
            )}

            {extractionStatus.companyBank && (
              <div className="success-banner animate-fade-in mt-6">
                <CheckCircle className="text-success" size={24} />
                <div>
                  <strong>Company Banking Details Verified!</strong>
                  <p>Company Bank: {formData.bankName} | A/C: {formData.accountNumber}</p>
                </div>
              </div>
            )}

            {formData.entityType !== 'Individual' && verifiedPartnerBanks > 0 && (
              <div className="success-banner animate-fade-in mt-4">
                <CheckCircle className="text-success" size={24} />
                <div>
                  <strong>Partner Banking Details Verified!</strong>
                  <p>{verifiedPartnerBanks} of {formData.partnerBankDetails.length} partner/director bank records have been verified.</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: OCR Extraction */}
        {currentStep === 2 && (
          <div className="step-content animate-fade-in">
            <h2>Identity & Address OCR</h2>
            <p className="mb-6 text-sm text-muted">Upload ID and Address proofs for the company and all partners/directors.</p>
            
            <div className="form-grid">
              <div className="input-group full-width">
                <label>Company / Firm ID Proof</label>
                <div className="file-upload-zone">
                  <FileText size={24} className="mb-2 text-muted" />
                  <p>Click to Upload Company ID</p>
                  <input type="file" onChange={(e) => handleCompanyOcrFileChange('idProofFile', e.target.files[0])} />
                </div>
              </div>
              <div className="input-group full-width">
                <label>Company / Firm Address Proof</label>
                <div className="file-upload-zone">
                  <FileText size={24} className="mb-2 text-muted" />
                  <p>Click to Upload Company Address</p>
                  <input type="file" onChange={(e) => handleCompanyOcrFileChange('addressProofFile', e.target.files[0])} />
                </div>
              </div>
            </div>

            <div className="banking-options mt-6">
              <div className="banking-card glass-panel">
                <h3>Company / Firm OCR</h3>
                <p>Extract company identity and address data from the uploaded documents.</p>
                <button className="btn btn-primary mt-4" onClick={simulateCompanyOCRExtraction} disabled={activeExtraction !== null}>
                  {isExtracting('companyOcr') ? <><Loader2 className="spin" size={16}/> Extracting...</> : 'Run Company OCR'}
                </button>
              </div>
            </div>

            {formData.entityType !== 'Individual' && (
              <>
                <div className="section-divider"></div>
                <h3 className="section-subheading mt-6">Partner / Director OCR</h3>
                {formData.partnerOcrDetails.map((ocr, idx) => (
                  <div className="partner-card glass-panel mt-4" key={idx}>
                    <div className="flex justify-between items-center mb-3">
                      <h4>Partner / Director {idx + 1} OCR</h4>
                    </div>
                    <button className="btn btn-outline mb-4" onClick={() => simulatePartnerOCRExtraction(idx)} disabled={activeExtraction !== null}>
                      {isExtracting(`partnerOcr-${idx}`) ? <><Loader2 className="spin" size={16}/> Extracting...</> : `Run Partner ${idx + 1} OCR`}
                    </button>
                    <div className="form-grid">
                      <div className="input-group">
                        <label>ID Proof</label>
                        <div className="file-upload-zone">
                          <p>Upload Partner {idx + 1} ID</p>
                          <input type="file" onChange={(e) => handlePartnerOcrChange(idx, 'idProofFile', e.target.files[0])} />
                        </div>
                      </div>
                      <div className="input-group">
                        <label>Address Proof</label>
                        <div className="file-upload-zone">
                          <p>Upload Partner {idx + 1} Address</p>
                          <input type="file" onChange={(e) => handlePartnerOcrChange(idx, 'addressProofFile', e.target.files[0])} />
                        </div>
                      </div>
                      <div className="input-group">
                        <label>Full Name</label>
                        <input type="text" value={ocr.fullName} onChange={(e) => handlePartnerOcrChange(idx, 'fullName', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>Date of Birth</label>
                        <input type="date" value={ocr.dob} onChange={(e) => handlePartnerOcrChange(idx, 'dob', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>PAN Number</label>
                        <input type="text" value={ocr.pan} onChange={(e) => handlePartnerOcrChange(idx, 'pan', e.target.value)} />
                      </div>
                    </div>
                  </div>
                ))}
              </>
            )}

            {extractionStatus.companyOcr && (
              <div className="success-banner animate-fade-in mt-6">
                <CheckCircle className="text-success" size={24} />
                <div>
                  <strong>Company OCR Extraction Successful!</strong>
                  <p>Company: {formData.fullName}, {formData.individualPan}</p>
                </div>
              </div>
            )}

            {formData.entityType !== 'Individual' && verifiedPartnerOcr > 0 && (
              <div className="success-banner animate-fade-in mt-4">
                <CheckCircle className="text-success" size={24} />
                <div>
                  <strong>Partner OCR Extraction Successful!</strong>
                  <p>{verifiedPartnerOcr} of {formData.partnerOcrDetails.length} partner/director OCR records have been extracted and pre-filled.</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STEP 3: Personal & KYC */}
        {currentStep === 3 && (
          <div className="step-content animate-fade-in">
            {/* <div className="flex justify-between items-center border-bottom mb-4 pb-2">
              <h2>Entity & Contact Details</h2>
              <span className="badge badge-success">Smart Pre-filled</span>
            </div> */}

            <h3 className="section-subheading">Entity Setup</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Entity Type</label>
                <select name="entityType" value={formData.entityType} onChange={handleEntityTypeChange}>
                  <option>Individual</option>
                  <option>Proprietorship</option>
                  <option>Partnership</option>
                  <option>Firm</option>
                </select>
              </div>
              {formData.entityType !== 'Individual' && (
                <div className="input-group">
                  <label>Number of Partners / Directors</label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={formData.numberOfPartners}
                    onChange={handleNumberOfPartnersChange}
                    placeholder="Enter number"
                  />
                  {formData.partnerCountError && <p className="text-error text-sm">{formData.partnerCountError}</p>}
                </div>
              )}
            </div>

            <div className="section-divider"></div>
            <h3 className="section-subheading">Company / Vendor Details</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Company / Vendor Name</label>
                <input type="text" name="companyName" value={formData.companyName} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Vendor Category</label>
                <select name="vendorCategory" value={formData.vendorCategory} onChange={handleInputChange}>
                  {VENDOR_CATEGORIES.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
              </div>
              <div className="input-group">
                <label>Date of Incorporation / DOB</label>
                <input type="date" name="dateOfInc" value={formData.dateOfInc} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Designation</label>
                <input type="text" name="designation" value={formData.designation} onChange={handleInputChange} placeholder="e.g., Director" />
              </div>
              <div className="input-group">
                <label>Phone Number</label>
                <div className="input-with-button">
                  <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} />
                  <button type="button" className="btn btn-secondary" onClick={handleSendPhoneOtp} disabled={!formData.phone || formData.phoneVerified}>
                    {formData.phoneVerified ? 'Verified' : 'Verify Phone'}
                  </button>
                </div>
                {formData.showPhoneOtp && !formData.phoneVerified && (
                  <div className="otp-row">
                    <input type="text" name="phoneOtp" value={formData.phoneOtp} onChange={handleInputChange} placeholder="Enter OTP" />
                    <button type="button" className="btn btn-primary" onClick={handleVerifyPhoneOtp}>Verify OTP</button>
                  </div>
                )}
                {formData.phoneOtpError && <p className="text-error text-sm">{formData.phoneOtpError}</p>}
                {formData.phoneVerified && <p className="text-success text-sm">Phone verified successfully.</p>}
              </div>
              <div className="input-group">
                <label>Alternate Contact Number</label>
                <input type="tel" name="altContactNumber" value={formData.altContactNumber} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Email Address</label>
                <div className="input-with-button">
                  <input type="email" name="email" value={formData.email} onChange={handleInputChange} />
                  <button type="button" className="btn btn-secondary" onClick={handleSendEmailOtp} disabled={!formData.email || formData.emailVerified}>
                    {formData.emailVerified ? 'Verified' : 'Verify Email'}
                  </button>
                </div>
                {formData.showEmailOtp && !formData.emailVerified && (
                  <div className="otp-row">
                    <input type="text" name="emailOtp" value={formData.emailOtp} onChange={handleInputChange} placeholder="Enter OTP" />
                    <button type="button" className="btn btn-primary" onClick={handleVerifyEmailOtp}>Verify OTP</button>
                  </div>
                )}
                {formData.emailOtpError && <p className="text-error text-sm">{formData.emailOtpError}</p>}
                {formData.emailVerified && <p className="text-success text-sm">Email verified successfully.</p>}
              </div>
              <div className="input-group">
                <label>Registered Address</label>
                <input type="text" name="registeredAddress" value={formData.registeredAddress} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Select Serving State</label>
                <input type="text" name="serviceState" value={formData.serviceState} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Select Serving City</label>
                <input type="text" name="serviceCity" value={formData.serviceCity} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Select Serving Branch</label>
                <input type="text" name="serviceBranch" value={formData.serviceBranch} onChange={handleInputChange} />
              </div>
            </div>

            <div className="section-divider"></div>
            <h3 className="section-subheading">Business Details</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Vendor Annual Turnover (INR)</label>
                <input type="text" name="annualTurnover" value={formData.annualTurnover} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Years of Experience</label>
                <input type="text" name="yearsOfExperience" value={formData.yearsOfExperience} onChange={handleInputChange} />
              </div>
              <div className="input-group full-width">
                <label>Key Clients Worked With</label>
                <input type="text" name="keyClients" value={formData.keyClients} onChange={handleInputChange} placeholder="Ex: HDFC, ICICI, etc." />
              </div>
            </div>

            <div className="section-divider"></div>
            <h3 className="section-subheading">Reference Details</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Reference Name</label>
                <input type="text" name="refName" value={formData.refName} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Contact Details</label>
                <input type="text" name="refContact" value={formData.refContact} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Relationship with Vendor</label>
                <input type="text" name="refRelationship" value={formData.refRelationship} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Email ID</label>
                <input type="email" name="refEmail" value={formData.refEmail} onChange={handleInputChange} />
              </div>
            </div>

            <div className="section-divider"></div>
            <h3 className="section-subheading">Vendor Met & Assessed By</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Employee Name</label>
                <input type="text" name="assessedByName" value={formData.assessedByName} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Department</label>
                <input type="text" name="assessedByDepartment" value={formData.assessedByDepartment} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Designation</label>
                <input type="text" name="assessedByDesignation" value={formData.assessedByDesignation} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Date of Meeting</label>
                <input type="date" name="meetingDate" value={formData.meetingDate} onChange={handleInputChange} />
              </div>
            </div>

            <div className="section-divider"></div>
            <h3 className="section-subheading">ISFC SPOC Details</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>SPOC Name</label>
                <input type="text" name="spocName" value={formData.spocName} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Designation</label>
                <input type="text" name="spocDesignation" value={formData.spocDesignation} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Email ID</label>
                <input type="email" name="spocEmail" value={formData.spocEmail} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Phone Number</label>
                <input type="tel" name="spocPhone" value={formData.spocPhone} onChange={handleInputChange} />
              </div>
            </div>

            {formData.entityType === 'Individual' ? (
              <>
                <h3 className="section-subheading">Key Person Details</h3>
                <div className="form-grid">
                  <div className="input-group">
                    <label>Full Name (Pre-filled from ID Proof)</label>
                    <input type="text" name="fullName" value={formData.fullName} onChange={handleInputChange} className="prefilled" />
                  </div>
                  <div className="input-group">
                    <label>Date of Birth (Pre-filled from ID Proof)</label>
                    <input type="date" name="dob" value={formData.dob} onChange={handleInputChange} className="prefilled" />
                  </div>
                  <div className="input-group">
                    <label>Father's Name</label>
                    <input type="text" name="fatherName" value={formData.fatherName} onChange={handleInputChange} />
                  </div>
                  <div className="input-group">
                    <label>Designation</label>
                    <input type="text" name="designation" value={formData.designation} onChange={handleInputChange} placeholder="e.g., Director" />
                  </div>
                </div>
              </>
            ) : (
              <>
                <h3 className="section-subheading">Partner / Director Details</h3>
                {formData.partnerDetails.length === 0 && (
                  <p className="text-sm text-muted">Enter the number of partners or directors above to capture details for each individual.</p>
                )}
                {formData.partnerDetails.map((partner, idx) => (
                  <div className="partner-card glass-panel mt-4" key={idx}>
                    <div className="flex justify-between items-center mb-3">
                      <h4>Partner / Director {idx + 1}</h4>
                      <span className="badge badge-secondary">{formData.entityType}</span>
                    </div>
                    <div className="form-grid">
                      <div className="input-group">
                        <label>Full Name</label>
                        <input type="text" value={partner.fullName} onChange={(e) => handlePartnerDetailChange(idx, 'fullName', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>Date of Birth</label>
                        <input type="date" value={partner.dob} onChange={(e) => handlePartnerDetailChange(idx, 'dob', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>PAN Number</label>
                        <input type="text" value={partner.pan} onChange={(e) => handlePartnerDetailChange(idx, 'pan', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>Designation / Role</label>
                        <input type="text" value={partner.designation} onChange={(e) => handlePartnerDetailChange(idx, 'designation', e.target.value)} placeholder="e.g., Director" />
                      </div>
                      <div className="input-group">
                        <label>Role / Share %</label>
                        <input type="text" value={partner.role} onChange={(e) => handlePartnerDetailChange(idx, 'role', e.target.value)} placeholder="e.g., Partner / 50%" />
                      </div>
                      <div className="input-group">
                        <label>Share Percentage</label>
                        <input type="text" value={partner.sharePercentage} onChange={(e) => handlePartnerDetailChange(idx, 'sharePercentage', e.target.value)} placeholder="50" />
                      </div>
                    </div>
                    <div className="section-divider"></div>
                    <div className="flex justify-between items-center">
                      <h4 className="mt-4">Bank Details for Partner {idx + 1}</h4>
                      <button
                        type="button"
                        className="btn btn-outline"
                        onClick={() => simulatePartnerBankingExtraction(idx)}
                        disabled={activeExtraction !== null}
                      >
                        {isExtracting(`partnerBank-${idx}`) ? <><Loader2 className="spin" size={14}/> Verifying...</> : 'Verify Bank'}
                      </button>
                    </div>
                    <div className="form-grid mt-3">
                      <div className="input-group">
                        <label>Bank Name</label>
                        <input type="text" value={formData.partnerBankDetails[idx]?.bankName || ''} onChange={(e) => handlePartnerBankChange(idx, 'bankName', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>Account Number</label>
                        <input type="text" value={formData.partnerBankDetails[idx]?.accountNumber || ''} onChange={(e) => handlePartnerBankChange(idx, 'accountNumber', e.target.value)} />
                      </div>
                      <div className="input-group">
                        <label>IFSC Code</label>
                        <input type="text" value={formData.partnerBankDetails[idx]?.ifscCode || ''} onChange={(e) => handlePartnerBankChange(idx, 'ifscCode', e.target.value)} />
                      </div>
                    </div>
                  </div>
                ))}
              </>
            )}

            <h3 className="section-subheading mt-6">KYC Information</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Individual PAN (Pre-filled)</label>
                <input type="text" name="individualPan" value={formData.individualPan} onChange={handleInputChange} className="prefilled" />
              </div>
              <div className="input-group">
                <label>GST Number</label>
                <input type="text" name="gstNumber" value={formData.gstNumber} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>MSME Registered?</label>
                <select name="msmeRegistered" value={formData.msmeRegistered} onChange={handleInputChange}>
                  <option>Yes</option><option>No</option>
                </select>
              </div>
            </div>

            <h3 className="section-subheading mt-6">RCU Business References (Manual Entry)</h3>
            <div className="form-grid">
              <div className="input-group">
                <label>Reference 1: Institution Name</label>
                <input type="text" name="ref1Inst" value={formData.ref1Inst} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Reference 1: Location & RM Name</label>
                <input type="text" name="ref1Location" value={formData.ref1Location} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Reference 2: Institution Name</label>
                <input type="text" name="ref2Inst" value={formData.ref2Inst} onChange={handleInputChange} />
              </div>
              <div className="input-group">
                <label>Reference 2: Location & RM Name</label>
                <input type="text" name="ref2Location" value={formData.ref2Location} onChange={handleInputChange} />
              </div>
            </div>
          </div>
        )}
        
        {/* STEP 4: Document Collection */}
        {currentStep === 4 && (
          <div className="step-content animate-fade-in">
            <h2>Additional Document Collection</h2>
            <p className="mb-4 text-sm text-muted">ID and Address proofs were already collected in Step 2. Showing remaining required documents for: <strong>{formData.vendorCategory}</strong></p>
            
            <div className="form-grid">
              {requiredDocs.map((doc, idx) => (
                <div className="input-group" key={idx}>
                  <label>Upload {doc}</label>
                  <div className="file-upload-zone">
                    <p>Click to Upload</p>
                    <input type="file" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* STEP 5: Payout & Stamp Selection */}
        {currentStep === 5 && (
          <div className="step-content animate-fade-in">
            <h2>Payout & Stamp Selection</h2>
            <div className="payout-grid">
              <div className="payout-card glass-panel selected">
                <div className="badge badge-success mb-2">Recommended</div>
                <h3>Standard Payout (A)</h3>
                <p className="payout-rate">1.50%</p>
                <p className="text-sm">Standard onboarding rate as per BRE.</p>
              </div>
              <div className="payout-card glass-panel">
                <h3>Premium Payout (B)</h3>
                <p className="payout-rate">1.75%</p>
                <p className="text-sm">Requires Business Head Approval.</p>
              </div>
            </div>
            
            <h3 className="section-subheading mt-6 mb-4">Stamp Duty Collection</h3>
            <div className="input-group w-50">
              <label>Select State</label>
              <select>
                <option>Delhi (Rs. 500/-)</option>
                <option>Haryana (Rs. 1000/-)</option>
                <option>Maharashtra (Rs. 500/-)</option>
              </select>
            </div>
          </div>
        )}
        
        {/* STEP 6: E-Signing */}
        {currentStep === 6 && (
          <div className="step-content animate-fade-in">
            <h2>E-Signing & Submission</h2>
            <div className="esign-container glass-panel">
              <div className="esign-status">
                <div className="status-icon pending"></div>
                <div>
                  <h3>Agreement Generation</h3>
                  <p>The Agreement is ready for e-signing via Leegality.</p>
                </div>
              </div>
              
              <div className="input-group mt-4">
                <label>Mobile Number for E-Sign Link</label>
                <input type="tel" value="9876543210" readOnly />
              </div>
              
              <button className="btn btn-primary mt-4">
                <Smartphone size={16} className="mr-2" /> Send E-Sign Link
              </button>
            </div>
          </div>
        )}

        <div className="onboarding-footer">
          <button className="btn btn-outline" onClick={prevStep} disabled={currentStep === 0}>
            Back
          </button>
          <button className="btn btn-primary" onClick={nextStep}>
            {currentStep === STEPS.length - 1 ? 'Submit Registration' : 'Save & Next'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
